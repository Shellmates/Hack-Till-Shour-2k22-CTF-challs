import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("TOKEN")


bot = commands.Bot(command_prefix="$")


@bot.event
async def on_ready():
    print(f"{bot.user.name} has connected to Discord !")


@bot.command(name="start")
async def start(ctx):
    await ctx.send("I promise that i will not hide anything from you.")


bot.run(TOKEN)
